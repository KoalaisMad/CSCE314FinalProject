// package app;

public class Stock {
        public static int Cokeava = 16;
        public static int KoolAidava = 16;
        public static int Spriteava = 16;
        public static int Pepsiava = 16;
        public static int Waterava = 16;
        public static int RootBeerava = 16;
        public static int GrilledCheeseR1ava = 32;
        public static int GrilledCheeseR2ava = 32;

        public static boolean Cokeresocted = false;
        public static boolean KoolAidresocted = false;
        public static boolean Spriteresocted = false;
        public static boolean Pepsiresocted = false;
        public static boolean Waterresocted = false;
        public static boolean RootBeerresocted = false;
        public static boolean GC1resocted = false;
        public static boolean GC2resocted = false;
}
