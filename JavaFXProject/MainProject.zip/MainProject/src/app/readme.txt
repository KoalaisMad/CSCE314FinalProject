README.txt - explain how to compile and run your project, clearly explain any additional features in this file

The project consists of 3 screen which include the main, adminp panel and the customer view. The inital screen 
prompts the user to take any action on which kind of user they are. Based on the user input, the code will take 
them to the admin panel or the customer panel.

The customer panel has the following functions: selecting items, deselecting items, paying, checking avaliabilty of an item.
The user can select the items and when he/she is ready to pay, they can click the pay button which will save the transaction in 
the system for the admin to view. The system also spits out when there is an item that it out of stock. 
Furthermore, there are multiple other feature that were in the process of implementation which include
displaying the selected items, and the shop vendor's message (Snoopy's message). However, with my knowledge on fxml being limited I wasn't 
able to debug having 3 controllers. Thus, had to output to the console rather than the GUI. Apart from my inability, I was able to switch 
between the GUI with the home, customer and admin buttons.

The admin panel consists of refilling each item and shows the summary of the sales. The summary include the number of things sold, their 
revenue, and the total income. 

Apart from the functionailty, most of the code is writed in the Controller.java which has all the logic, while MainView.fxml, new_screen_two.fxml,
and new_screen.fxml implement the logic from Controller.java and their own UI Componenets. They also utilize the styles.css to prompt better display. 

The Controller.java has Item class that implements a new item for every kind of objects. For, instance "Coke" will have the following properties 
name, price, quantity (avaliabilty), numberSold, and revenue of the item. The other classes in the Controller utilize Item class to maintain the functionaly of
the program.
